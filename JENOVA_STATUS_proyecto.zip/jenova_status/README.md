# JENOVA STATUS — Android MVP

Aplicación Android nativa (Java) para seleccionar una foto/vídeo, programar un recordatorio local y compartir el contenido a WhatsApp Business.

## Importante: alcance real
- WhatsApp Business no ofrece una API pública para publicar estados de forma programada.
- Esta versión programa un recordatorio y abre el flujo de compartir de WhatsApp Business; el usuario debe completar/confirmar la publicación dentro de WhatsApp.
- No publica con el teléfono bloqueado ni realiza toques automáticos en WhatsApp.
- El recordatorio depende de los permisos de notificaciones y alarmas del dispositivo. Algunos fabricantes pueden limitar tareas en segundo plano.

## Compilar APK
1. Abre esta carpeta en Android Studio (versión compatible con Android Gradle Plugin 8.6.1).
2. Deja que Gradle sincronice y descargue el Android Gradle Plugin.
3. Conecta un teléfono Android o usa un emulador.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/`.

Paquete: `com.jenova.status` · Versión: `1.0` · SDK mínimo: Android 6.0.
