package com.jenova.status;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String channel="jenova_reminders";
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"Recordatorios JENOVA",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(context,2,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(context,channel).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("JENOVA STATUS").setContentText("Es hora de publicar tu estado de WhatsApp Business").setContentIntent(pi).setAutoCancel(true).build();
        nm.notify(1001,n);
    }
}
