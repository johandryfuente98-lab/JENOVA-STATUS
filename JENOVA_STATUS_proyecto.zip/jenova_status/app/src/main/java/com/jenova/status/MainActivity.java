package com.jenova.status;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int PICK_MEDIA = 41;
    private Uri selectedUri;
    private String mime = "image/*";
    private TextView selectedLabel, scheduleLabel;
    private long scheduledAt = 0;
    private final String PREF = "jenova_status";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF171222);
        getWindow().setNavigationBarColor(0xFF100D18);
        requestNotificationPermission();
        buildUi();
        restoreSchedule();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 8);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22), dp(24), dp(22), dp(28)); root.setBackgroundColor(0xFF100D18);
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("JENOVA", 13, 0xFFE2C68D); brand.setLetterSpacing(.28f); root.addView(brand);
        TextView title = text("STATUS", 34, 0xFFFFFFFF); title.setTypeface(null, 1); root.addView(title);
        TextView subtitle = text("Programa tus publicaciones de WhatsApp Business", 14, 0xFFB9B2C5); subtitle.setPadding(0,0,0,dp(22)); root.addView(subtitle);

        LinearLayout card = new LinearLayout(this); card.setOrientation(1); card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackground(bg(0xFF211B2D,20)); root.addView(card);
        card.addView(text("1 · CONTENIDO", 12, 0xFFE2C68D));
        selectedLabel = text("Todavía no has seleccionado una foto o vídeo", 15, 0xFFFFFFFF); selectedLabel.setPadding(0,dp(12),0,dp(14)); card.addView(selectedLabel);
        Button choose = button("Elegir foto o vídeo"); card.addView(choose); choose.setOnClickListener(v -> pickMedia());

        TextView gap = text("", 8, 0); root.addView(gap);
        LinearLayout timing = new LinearLayout(this); timing.setOrientation(1); timing.setPadding(dp(18),dp(18),dp(18),dp(18)); timing.setBackground(bg(0xFF211B2D,20)); root.addView(timing);
        timing.addView(text("2 · FECHA Y HORA",12,0xFFE2C68D));
        scheduleLabel = text("No hay publicación programada",15,0xFFFFFFFF); scheduleLabel.setPadding(0,dp(12),0,dp(14)); timing.addView(scheduleLabel);
        Button schedule = button("Programar estado"); timing.addView(schedule); schedule.setOnClickListener(v -> chooseDateTime());

        TextView note = text("3 · PUBLICAR",12,0xFFE2C68D); note.setPadding(0,dp(24),0,dp(10)); root.addView(note);
        Button publish = button("Compartir en WhatsApp Business"); root.addView(publish); publish.setOnClickListener(v -> shareToBusiness());
        TextView disclaimer = text("JENOVA STATUS te recuerda cuándo publicar y prepara el contenido para compartir. Por las restricciones de WhatsApp, la publicación final debe confirmarse dentro de WhatsApp Business. No publica en segundo plano ni evita el bloqueo del teléfono.",12,0xFFAAA2B8);
        disclaimer.setPadding(0,dp(18),0,0); root.addView(disclaimer);
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextAllCaps(false); b.setTextColor(0xFF171222); b.setTextSize(14); b.setTypeface(null,1); b.setBackground(bg(0xFFE2C68D,14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); b.setLayoutParams(p); return b;
    }
    private void pickMedia() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});
        startActivityForResult(i,PICK_MEDIA);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==PICK_MEDIA && result==RESULT_OK && data!=null && data.getData()!=null) {
            selectedUri=data.getData(); mime=getContentResolver().getType(selectedUri); if(mime==null) mime="image/*";
            try { getContentResolver().takePersistableUriPermission(selectedUri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            selectedLabel.setText("Contenido listo: "+(mime.startsWith("video")?"vídeo":"imagen"));
            getSharedPreferences(PREF,0).edit().putString("uri",selectedUri.toString()).putString("mime",mime).apply();
        }
    }
    private void chooseDateTime() {
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->{
            Calendar date=Calendar.getInstance(); date.set(y,m,d);
            new TimePickerDialog(this,(tv,h,min)->{
                date.set(Calendar.HOUR_OF_DAY,h); date.set(Calendar.MINUTE,min); date.set(Calendar.SECOND,0);
                if(date.getTimeInMillis()<=System.currentTimeMillis()){ toast("Elige una hora futura"); return; }
                scheduledAt=date.getTimeInMillis(); saveAndSchedule();
            },c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),true).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void saveAndSchedule() {
        getSharedPreferences(PREF,0).edit().putLong("when",scheduledAt).apply();
        scheduleLabel.setText("Programado para: "+DateFormat.getDateTimeInstance().format(scheduledAt));
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
            toast("Activa el permiso de alarmas exactas para recibir el aviso a la hora elegida.");
            try { startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); } catch(Exception ignored) {}
        }
        try { if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,scheduledAt,pi); else am.set(AlarmManager.RTC_WAKEUP,scheduledAt,pi); toast("Recordatorio programado"); }
        catch(SecurityException e){ toast("No se pudo programar. Revisa el permiso de alarmas."); }
    }
    private void restoreSchedule() {
        android.content.SharedPreferences p=getSharedPreferences(PREF,0); String u=p.getString("uri",null); if(u!=null){selectedUri=Uri.parse(u);mime=p.getString("mime","image/*");selectedLabel.setText("Contenido guardado: "+(mime.startsWith("video")?"vídeo":"imagen"));}
        scheduledAt=p.getLong("when",0); if(scheduledAt>System.currentTimeMillis()) scheduleLabel.setText("Programado para: "+DateFormat.getDateTimeInstance().format(scheduledAt));
    }
    private void shareToBusiness() {
        if(selectedUri==null){toast("Primero selecciona una foto o vídeo");return;}
        Intent send=new Intent(Intent.ACTION_SEND); send.setType(mime); send.putExtra(Intent.EXTRA_STREAM,selectedUri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); send.setPackage("com.whatsapp.w4b");
        try { startActivity(send); } catch(Exception e) { toast("No encuentro WhatsApp Business. Instálalo o actualízalo e inténtalo otra vez."); }
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
